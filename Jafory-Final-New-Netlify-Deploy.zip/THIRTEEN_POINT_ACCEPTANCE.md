# Jafory: 13-পয়েন্ট Acceptance Matrix

এই নথিটি প্রতিটি দাবি আলাদাভাবে যাচাই করার জন্য। **`পাস`** শুধুই live বা owner-phone প্রমাণ থাকলে ব্যবহার করা হবে; source/build pass একা `পাস` নয়।

| নং | প্রয়োজন | বর্তমান প্রমাণ | অবস্থা | পরের live যাচাই |
|---:|---|---|---|---|
| 1 | Desktop ও phone public layout আলাদা ও ব্যবহারযোগ্য | Phone home screenshot-এ compact storefront দেখা গেছে; current desktop release আবার দেখতে হবে | আংশিক | Phone + desktop public capture |
| 2 | UAE-তে Arabic default, Bangladesh Bengali, Global English | Clean UAE browser state-এ Arabic দেখা গেছে; explicit market switch তিনটিই আবার পরীক্ষা বাকি | আংশিক | তিন market switch |
| 3 | প্রতিটি fixed category-তে শুধু তার পণ্য | Live Electronics endpoint ও category route আগে 20 matching product দেয়; fixed-slug parser regression (`/categories/home-living`) নতুন source-এ আছে | আংশিক | New deploymentে 6 category route/count |
| 4 | Hero প্রতি 5 সেকেন্ডে ডানে-থেকে-বামে visibly slide | Live track transform `-2530px → -3795px` মাপা হয়েছে | পাস | Phone visual recheck |
| 5 | Blank Searching ছাড়াই public loading | New branded shell, skeleton ও fallback category source/build-validated; live cold response এখনও প্রায় 8 sec | আংশিক | Phone cold load |
| 6 | উপরে scroll-এ header, নিচে scroll-এ footer, শুরুতে দুটিই | Source logic আছে; phone scroll evidence বাকি | আংশিক | Phone scroll capture |
| 7 | একটি expandable floating contact: WhatsApp/Call/Chat/Email | Live DOM-এ একটি launcher, footer-dock contact link 0, এবং চার action পাওয়া গেছে; black footer strip এখনো visually confusing ছিল | আংশিক | Final source phone visual check |
| 8 | চারটি পর্যন্ত compare, remove ও clear | State tests আছে; live clear-all এবং remove আগে যাচাই হয়েছে | আংশিক | Phone 2-item remove + clear |
| 9 | Contact page-এ +971552650307 call action | Live contact page-এ `tel:+971552650307` দেখা গেছে | পাস | — |
| 10 | Category-organized admin Products list/edit/add/remove | Owner screenshot-এ Products list, category filter ও actions load হয়েছে; phone layout এখনও fail | আংশিক | Fixed phone layoutে product actions |
| 11 | Header/footer/sidebar/contact/social settings edit controls | Source panel আছে; owner Settings phone proof বাকি | আংশিক | Owner Settings capture |
| 12 | Admin editing fields optional | Admin product screen ও source audit-এ required authoring input নেই; save-flow proof বাকি | আংশিক | Optional blank save scenario |
| 13 | Guest/non-admin never reaches admin procedures | Live anonymous `admin.overview` returned HTTP 403 / `FORBIDDEN`; server bearer regression passes | পাস | Non-admin signed-in check |

## Screenshot-confirmed follow-up defects

| বিষয় | বর্তমান অবস্থা | Fix status |
|---|---|---|
| Extra bottom contact control | Owner screenshot-এ floating contact-এর নিচে `Contact Jafory` footer-dock action ছিল | Live DOM-এ link সরেছে; final source phone viewportে সম্পূর্ণ footer strip-ও সরানো হয়েছে |
| Phone admin shows desktop sidebar | Owner screenshot-এ phoneে fixed desktop sidebar ও compressed content দেখা গেছে | Live screenshotে sidebar সরে Menu/full-width দেখা গেছে; final sourceে duplicate header remove ও product list-first order pending final release |
| English admin direction | Owner screenshot-এ current admin is LTR | Live confirmed, retain regression guard |
| Open storefront | Owner screenshot-এর পরে public home দেখা গেছে | Live outcome observed, retain direct navigation implementation |

## Current source validation

The latest local source passes **34 active tests**, TypeScript checking, the production build, and a Netlify Function bundle check. No Supabase product, profile, role, review, affiliate record, or secret has been changed for this matrix.
