# Jafory: 13-পয়েন্ট Acceptance Matrix

এই নথিটি প্রতিটি দাবি আলাদাভাবে যাচাই করার জন্য। **`পাস`** শুধুই live বা owner-phone প্রমাণ থাকলে ব্যবহার করা হবে; source/build pass একা `পাস` নয়।

| নং | প্রয়োজন | বর্তমান প্রমাণ | অবস্থা | পরের live যাচাই |
|---:|---|---|---|---|
| 1 | Desktop ও phone public layout আলাদা ও ব্যবহারযোগ্য | 24 Aug owner-phone home/contact screenshots-এ compact storefront দেখা গেছে; current desktop release আবার দেখতে হবে | আংশিক | Desktop public capture |
| 2 | UAE-তে Arabic default, Bangladesh Bengali, Global English | Clean UAE browser state-এ Arabic দেখা গেছে; 25 Aug live switch-এ Bangladesh-এর পরে Bengali labels/content এবং Global-এর পরে English labels/content দেখা গেছে; Global-এ manually Bengali বেছে নিয়ে category route-এ গেলেও Bengali ছিল | পাস | — |
| 3 | প্রতিটি fixed category-তে শুধু তার পণ্য | 25 Aug route repair release-এর পরে direct `/categories/home-living` Bengali UI-তে Home & Living title, description এবং exactly 20 matching products দেখিয়েছে | পাস | — |
| 4 | Hero প্রতি 5 সেকেন্ডে ডানে-থেকে-বামে visibly slide | Live track transform `-2530px → -3795px` মাপা হয়েছে | পাস | Phone visual recheck |
| 5 | Blank Searching ছাড়াই public loading | New branded shell, skeleton ও fallback category source/build-validated; live cold response এখনও প্রায় 8 sec | আংশিক | Phone cold load |
| 6 | উপরে scroll-এ header, নিচে scroll-এ footer, শুরুতে দুটিই | Source logic আছে; phone scroll evidence বাকি | আংশিক | Phone scroll capture |
| 7 | একটি expandable floating contact: WhatsApp/Call/Chat/Email | Live DOM-এ একটি launcher, footer-dock contact link 0, এবং চার action পাওয়া গেছে; 24 Aug phone contact screenshot-এ একটিই floating launcher ও কোনো footer-dock contact action নেই | আংশিক | Phoneে launcher expand করে চার action দেখা |
| 8 | চারটি পর্যন্ত compare, remove ও clear | State tests আছে; live clear-all এবং remove আগে যাচাই হয়েছে | আংশিক | Phone 2-item remove + clear |
| 9 | Contact page-এ +971552650307 call action | Live contact page-এ `tel:+971552650307` দেখা গেছে | পাস | — |
| 10 | Category-organized admin Products list/edit/add/remove | 24 Aug owner-phone Products capture-এ Category filter, search, Current products list, category/status labels, Edit/Remove actions এবং list-first layout দেখা গেছে | আংশিক | One category-filter selection এবং collapsed optional Add Product expand check |
| 11 | Header/footer/sidebar/contact/social settings edit controls | 24 Aug owner-phone Settings screenshot-এ WhatsApp, public phone, chat, header notice, footer text, sidebar title ও six social fields দেখা গেছে | আংশিক | একটি harmless setting save করে persistence check |
| 12 | Admin editing fields optional | 24 Aug owner-phone Settings screenshot-এ nonessential fieldগুলোতে `Optional` placeholder দেখা গেছে; save-flow proof বাকি | আংশিক | Optional blank save scenario |
| 13 | Guest/non-admin never reaches admin procedures | Live anonymous `admin.overview` returned HTTP 403 / `FORBIDDEN`; server bearer regression passes | পাস | Non-admin signed-in check |

## Screenshot-confirmed follow-up defects

| বিষয় | বর্তমান অবস্থা | Fix status |
|---|---|---|
| Extra bottom contact control | Owner screenshot-এ floating contact-এর নিচে `Contact Jafory` footer-dock action ছিল | 24 Aug owner-phone public Contact capture-এ একটিই floating launcher আছে; আলাদা footer-dock contact action নেই |
| Phone admin shows desktop sidebar | Owner screenshot-এ phoneে fixed desktop sidebar ও compressed content দেখা গেছে | 24 Aug owner-phone Settings ও Products capture-এ fixed sidebar নেই, একটিই compact Control menu/header ও full-width workspace দেখা গেছে; Products screen-এ filter/search/current-list editor-এর আগে দেখা গেছে |
| English admin direction | Owner screenshot-এ current admin is LTR | 24 Aug owner-phone Settings capture-এ LTR confirmed; retain regression guard |
| Open storefront | Owner screenshot-এর পরে public home দেখা গেছে | 24 Aug owner screenshot-এ Admin থেকে ফেরার পর public home দেখা গেছে |

## Current source validation

The latest local source passes **35 active tests**, TypeScript checking, the production build, and a Netlify Function bundle check. The browser-key build mapping repair was pushed as GitHub commit `ec29fd6`, and the next live bundle proved the effective public browser key is nonempty. No Supabase product, profile, role, review, affiliate record, or secret has been changed for this matrix.
