export type JaforyMarket = "uae" | "bangladesh" | "global";

const gulfTimeZones = new Set([
  "Asia/Dubai",
  "Asia/Riyadh",
  "Asia/Qatar",
  "Asia/Kuwait",
  "Asia/Bahrain",
  "Asia/Muscat",
]);

export function marketForTimeZone(timeZone: string): JaforyMarket {
  if (timeZone === "Asia/Dhaka") return "bangladesh";
  if (gulfTimeZones.has(timeZone)) return "uae";
  return "global";
}
