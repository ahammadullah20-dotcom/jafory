# Live release evidence — 2026-08-25

## Public storefront after GitHub archive replacement

The live URL `https://jafory.netlify.app/` was opened and refreshed in the sandbox browser after the GitHub source archive replacement. The page title is `Jafory | Discover, Compare & Choose Smarter`. The live storefront rendered beyond its initial skeleton: market options were visible for UAE, Bangladesh, Pakistan, India, and Global; language options were visible for Arabic, Bengali, Urdu, Hindi, and English; the header exposed Sign in and Menu; category routes exposed Electronics, Fashion, Home & Living, Beauty & Wellness, and Daily Essentials; the compare entry was visible; and the public page rendered five hero-slide controls including previous/next controls.

The extracted live page also contained public product cards and owned `/jafory-media/` image paths, plus the configured WhatsApp, Call, Chat, and Email actions. The public contact action included `tel:+971552650307`. The first screenshot briefly showed the expected branded skeleton while data was loading; the follow-up browser view showed the populated storefront and hero content, including a visible Fashion slide. No authenticated route was opened and no account credentials or sensitive operation were used.

## Pending live owner verification

The owner’s actual magic-link callback and owner-admin session still require a clean Chrome tab on the owner device. The release is not marked as fully live-acceptance-complete until the owner confirms `/admin` reaches the dashboard, Products/Settings load, and sign-out works. No Supabase data, roles, reviews, affiliate records, or secrets were modified during this audit.

## Anonymous protected-route verification

The live `/admin` URL rendered the branded `Sign in to access the Jafory control panel` state with `Administrator access is required to manage Jafory content` and a Sign in button. Opening the live `/ad` URL resolved to `/admin` and rendered the same protected sign-in state. Both paths were nonblank and no authentication action was initiated.

## GitHub source synchronization evidence

After the authorized update, `ahammadullah20-dotcom/jafory` main contains only `Jafory-Final-New-Netlify-Deploy.zip` and `README.md` at repository root. The archive size is 7,364,704 bytes; GitHub blob SHA is `959c300e679ad4be9afbbcdb6acf69120e6abfc9`; main commit is `a6b6c781ba409cf5c50b0958575ff7cc0b131927`. Downloading the GitHub raw archive produced SHA-256 `15fe277fefb9c07bede0141e64be0934434050ad6354e7443501d0248498c0f1`, matching the local `/home/ubuntu/Jafory-Final-Admin-Auth-Hardening.zip`. This proves the repository replacement and archive integrity. Netlify's internal deploy ID/status is not exposed by the GitHub contents API; live public route checks are the available runtime evidence.
