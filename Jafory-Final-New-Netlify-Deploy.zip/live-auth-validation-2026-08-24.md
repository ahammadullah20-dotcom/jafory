# Live authentication validation — 24 August 2026

- The user triggered a Netlify no-cache production deploy at approximately 09:38 local time. The Netlify log showed build, deploy, cleanup, and `Site is live` completed.
- Fresh production bundle inspected at `https://jafory.netlify.app/assets/index-Y67B_lkS.js`.
- The bundle contains an anon/publishable-key marker and at least one Supabase host marker.
- The literal invalid fallback and browser guard strings also remain in the minified source; their mere presence is not sufficient proof that the fallback is active. The next verification must inspect the effective client configuration around the compiled expression and retest sign-in after the deployed asset has settled.
- No Supabase data, profiles, roles, reviews, affiliate data, or production source files were changed by this validation.

## Corrected archive release

The corrected archive was pushed to `ahammadullah20-dotcom/jafory` as commit `ec29fd6` after the owner granted the GitHub Connector access to the selected `jafory` repository. A fresh visit to the public homepage immediately after the push still returned the prior asset view, so the next check must establish whether Netlify has finished consuming the new GitHub commit before making any sign-in conclusion.

At the first post-push asset probe, the browser page still referenced the former `index-Y67B_lkS.js`, but refetching that URL returned HTML rather than JavaScript. This is consistent with an asset rollover during a completed deployment. A subsequent full navigation continued to render the public home page, so the next step is to inspect the active script source and then invoke the normal sign-in action only if the updated auth key is compiled into it.

The active production asset changed to `index-C-AAPXTd.js`. Its compiled client configuration contains both the Supabase project URL and a nonempty publishable browser key, confirming that the Vite mapping repair is live. A separate unauthenticated request to `admin.overview` returned HTTP 403 with `FORBIDDEN`, confirming that the corrected deployment did not weaken server-side guest admin protection.

Public regional switching was rechecked on the corrected deployment: selecting Bangladesh changed the visible interface to Bengali, and selecting Global changed it to English. The UAE state had already rendered Arabic in a clean anonymous browser session.

The manual-language persistence check also succeeded: after selecting Bengali while Global was active, visible Bengali labels remained after navigating to `/categories/home-living`. However, that direct category route incorrectly rendered the all-categories index and loading skeleton rather than the expected Home & Living catalogue. This is a separate, confirmed route-dispatch regression and must be repaired before final acceptance.
