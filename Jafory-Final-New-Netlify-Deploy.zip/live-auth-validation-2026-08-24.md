# Live authentication validation — 24 August 2026

- The user triggered a Netlify no-cache production deploy at approximately 09:38 local time. The Netlify log showed build, deploy, cleanup, and `Site is live` completed.
- Fresh production bundle inspected at `https://jafory.netlify.app/assets/index-Y67B_lkS.js`.
- The bundle contains an anon/publishable-key marker and at least one Supabase host marker.
- The literal invalid fallback and browser guard strings also remain in the minified source; their mere presence is not sufficient proof that the fallback is active. The next verification must inspect the effective client configuration around the compiled expression and retest sign-in after the deployed asset has settled.
- No Supabase data, profiles, roles, reviews, affiliate data, or production source files were changed by this validation.

## Corrected archive release

The corrected archive was pushed to `ahammadullah20-dotcom/jafory` as commit `ec29fd6` after the owner granted the GitHub Connector access to the selected `jafory` repository. A fresh visit to the public homepage immediately after the push still returned the prior asset view, so the next check must establish whether Netlify has finished consuming the new GitHub commit before making any sign-in conclusion.

At the first post-push asset probe, the browser page still referenced the former `index-Y67B_lkS.js`, but refetching that URL returned HTML rather than JavaScript. This is consistent with an asset rollover during a completed deployment. A subsequent full navigation continued to render the public home page, so the next step is to inspect the active script source and then invoke the normal sign-in action only if the updated auth key is compiled into it.

The active production asset changed to `index-C-AAPXTd.js`. Its compiled client configuration contains both the Supabase project URL and a nonempty publishable browser key, confirming that the Vite mapping repair is live. A separate unauthenticated request to `admin.overview` returned HTTP 403 with `FORBIDDEN`, confirming that the corrected deployment did not weaken server-side guest admin protection.

Public regional switching was rechecked on the corrected deployment: selecting Bangladesh changed the visible interface to Bengali, and selecting Global changed it to English. The UAE state had already rendered Arabic in a clean anonymous browser session.

The manual-language persistence check also succeeded: after selecting Bengali while Global was active, visible Bengali labels remained after navigating to `/categories/home-living`. However, that direct category route incorrectly rendered the all-categories index and loading skeleton rather than the expected Home & Living catalogue. This is a separate, confirmed route-dispatch regression and must be repaired before final acceptance.

The category route repair was pushed as GitHub commit `a523c26`. After the deployment settled, direct `/categories/home-living` correctly rendered the Bengali Home & Living title, description and exactly 20 matching products. The initial category skeleton remains brief during the data request, but it resolves to the matching catalogue.

The cross-device locale/media release was pushed as GitHub commit `e66e7a1`. Fresh production home-page inspection confirmed five selectable markets (UAE, Bangladesh, Pakistan, India, Global) and five selectable interface languages (Arabic, Bengali, Urdu, Hindi, English) in the public header. The browser was retaining a manually chosen Bengali interface at the time of the check, which is expected. Public markup contains the one floating contact launcher and its four destinations; the removed footer-dock tagline is absent from the current StorefrontLayout source release.

The production public-media audit after commit `e66e7a1` returned `total: 118`, `imageUrlPresent: 118`, and `missingImageUrl: 0`. Legacy expansion image paths remain rejected because they are unrelated to their product mappings; cards without an exact verified asset use a package-owned category-relevant visual rather than a blank placeholder or a misleading unrelated product photo.

After clearing only the browser-local market/language preferences, selecting Pakistan switched the live interface into Urdu and selecting India switched it into Hindi. Both live checks preserved the five-item market selector and five-item language selector. This confirms the Pakistan/India defaults work when no manual language preference has been set.

The owner-supplied 25 Aug recording was reviewed end-to-end. It confirmed strict search failures for `Electronic` and `Home & living`, an editor rendered after the full product list, URL-only media fields, and the reported mobile desktop-mode layout issue. The staged repair replaces strict matching with tokenized minimum matching, opens the product editor at the top on Edit/Add, adds protected direct Supabase Storage image/video controls, and stops a wide desktop-site viewport from being forced into the compact mobile admin shell. Local 980px desktop-width capture confirms the storefront is composed as a true desktop header/nav rather than a phone layout; the local anonymous admin capture correctly remains protected, so signed-in editor visuals still require owner-device verification after release.

During a subsequent public contact-launcher spot-check, an imprecise automated coordinate selected a product card and navigated to its public detail route. No form, save, edit, remove, affiliate, or other data-changing control was invoked. The four contact destinations remain present in the public page markup, while a clean phone visual expansion capture remains an outstanding acceptance item.
