import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

export default function AccountPage() {
  const { loading, user, isAuthenticated, logout } = useAuth();

  if (loading) return <main className="account-page"><p>Loading your Jafory account…</p></main>;
  if (!isAuthenticated) return <main className="account-page"><section><p className="account-page__eyebrow">Jafory account</p><h1>Sign in to continue</h1><p>Sign in to submit authentic product reviews and manage your account access.</p><button className="account-page__button" onClick={() => void startLogin()}>Sign in</button></section></main>;

  const isAdmin = user?.role === "admin";
  return <main className="account-page"><section><p className="account-page__eyebrow">Your Jafory account</p><h1>{user?.name || "Signed-in user"}</h1><p>{isAdmin ? "Your account is authorised to manage Jafory content." : "You can browse products and submit reviews. Administrator access is restricted to accounts explicitly granted the admin role."}</p><div className="account-page__actions">{isAdmin ? <a className="account-page__button" href="/admin">Open admin panel</a> : <a className="account-page__button" href="/">Browse products</a>}<button className="account-page__button account-page__button--secondary" onClick={() => void logout()}>Sign out</button></div></section></main>;
}
