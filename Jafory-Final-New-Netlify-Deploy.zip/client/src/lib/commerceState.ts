export type ClientMarket = "uae" | "bangladesh" | "global";
export type ClientLanguage = "en" | "ar" | "bn";

const languageDefaults: Record<ClientMarket, ClientLanguage> = { uae: "ar", bangladesh: "bn", global: "en" };

export function isClientMarket(value: string): value is ClientMarket {
  return value === "uae" || value === "bangladesh" || value === "global";
}

export function defaultLanguageForMarket(market: ClientMarket): ClientLanguage {
  return languageDefaults[market];
}

export function toggleComparisonProduct(current: string[], productId: string) {
  if (current.includes(productId)) return current.filter(id => id !== productId);
  return current.length < 4 ? [...current, productId] : current;
}

export function clearComparisonProducts() {
  return [] as string[];
}
