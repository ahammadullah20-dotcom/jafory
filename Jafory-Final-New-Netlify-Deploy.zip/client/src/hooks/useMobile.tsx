import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function isPhoneUserAgent(userAgent: string) {
  return /android|iphone|ipod|mobile|iemobile|opera mini/i.test(userAgent);
}

export function isPhoneLikeDevice({ compactViewport, phoneUserAgent, coarsePointer, touchPoints }: { compactViewport: boolean; phoneUserAgent: boolean; coarsePointer: boolean; touchPoints: number }) {
  // Desktop-site mode on a phone keeps a phone user agent but provides a wide
  // viewport. Viewport width is therefore the only reliable compact-shell cue.
  return compactViewport;
}

function isMobileEnvironment() {
  const compactViewport = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`).matches;
  const phoneUserAgent = isPhoneUserAgent(navigator.userAgent);
  const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
  return isPhoneLikeDevice({ compactViewport, phoneUserAgent, coarsePointer, touchPoints: navigator.maxTouchPoints ?? 0 });
}

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(
    undefined
  );

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const coarsePointerMql = window.matchMedia("(pointer: coarse)");
    const onChange = () => {
      setIsMobile(isMobileEnvironment());
    };
    mql.addEventListener("change", onChange);
    coarsePointerMql.addEventListener("change", onChange);
    setIsMobile(isMobileEnvironment());
    return () => { mql.removeEventListener("change", onChange); coarsePointerMql.removeEventListener("change", onChange); };
  }, []);

  return !!isMobile;
}
