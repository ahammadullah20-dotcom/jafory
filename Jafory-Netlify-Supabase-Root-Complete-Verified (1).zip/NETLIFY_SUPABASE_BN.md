# Jafory পূর্ণাঙ্গ Netlify + Supabase নির্দেশনা

## গুরুত্বপূর্ণ সিদ্ধান্ত

এই version শুধু static drag-and-drop site নয়। Product catalogue, magic-link sign-in, admin role, product edit, active/inactive, hero slide, social link, affiliate link, specification এবং review moderation স্থায়ীভাবে চালাতে Netlify Functions এবং Supabase environment variables একসাথে লাগবে। v3 static ZIP upload করবেন না।

## Netlify-তে নতুন site তৈরি

১. Netlify-তে নতুন site খুলুন বা existing site-এর Git repository/build configuration ব্যবহার করুন।

২. Project root হিসেবে এই repository-টি ব্যবহার করুন। `netlify.toml`-এ build command `pnpm build`, publish directory `dist/public`, এবং Functions directory `netlify/functions` সেট করা আছে।

৩. Netlify Site settings → Environment variables-এ এগুলো যোগ করুন:

- `SUPABASE_URL`: Supabase Project URL; `/rest/v1` suffix দেবেন না।
- `SUPABASE_ANON_KEY`: Supabase Publishable/anon public key।
- `SUPABASE_SERVICE_ROLE_KEY`: Supabase Secret/service-role key; শুধু server-side রাখবেন।
- `JWT_SECRET`: project-এর existing secure value।

৪. Supabase Authentication → URL Configuration-এ Netlify site URL এবং `/account` callback অনুমোদিত redirect URL হিসেবে যোগ করুন। উদাহরণ: `https://your-site.netlify.app/account`।

৫. প্রথমবার email magic link দিয়ে owner account তৈরি করুন। Supabase-এর `profiles` table-এ owner profile-এর `role` value `admin` করতে হবে। এটি না করলে sign-in হবে, কিন্তু Admin panel blocked থাকবে।

৬. Admin panel-এ sign in করে Contact URL, WhatsApp, social links, hero slides, affiliate links, product image URL এবং active/featured state যাচাই করুন।

## নিরাপত্তা

`SUPABASE_SERVICE_ROLE_KEY` কখনো browser code, GitHub, screenshot বা chat-এ রাখবেন না। Public browser build-এ কেবল URL এবং anon/publishable key থাকা উচিত। কোনো customer review, rating বা testimonial নিজে থেকে বানানো যাবে না।

## Validation checklist

Home-এ 118টি canonical product থাকবে: Electronics 20, Fashion 20, Home & Living 20, Beauty & Wellness 20, Daily Essentials 20 এবং AI Learn / AI Tech 18। Category, product detail, search, compare, contact, readiness, account এবং admin routes সরাসরি hash ছাড়া খুলতে হবে।
