# Jafory Netlify + Supabase সম্পূর্ণ package

এই package full-stack। `netlify.toml`-এর build command frontend build করে এবং `netlify/functions/api.ts` Supabase-backed API চালায়। শুধু Netlify-এর static drag-and-drop-এ source ZIP ছেড়ে দিলে server functions build নাও হতে পারে; Netlify-তে repository import বা Netlify CLI দিয়ে deploy করতে হবে।

Netlify Site settings → Environment variables-এ `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, এবং `JWT_SECRET` যোগ করুন। Supabase URL-এ `/rest/v1` suffix দেবেন না। `SUPABASE_SERVICE_ROLE_KEY` কেবল server-side secret হিসেবে রাখবেন।

Supabase Authentication → URL Configuration-এ আপনার Netlify URL এবং `${SITE_URL}/account` redirect URL যোগ করুন। প্রথম login-এর পরে existing admin profile দিয়েই `/admin` খুলবে; role পরিবর্তনের প্রয়োজন নেই যদি profile-এর role আগে থেকেই `admin` থাকে।

Deploy করার আগে এই package-এর root-এ `package.json`, `netlify.toml`, `client/`, `server/`, `shared/`, এবং `netlify/functions/` আছে কি না দেখুন। Existing Netlify site বা Supabase data delete করবেন না।
