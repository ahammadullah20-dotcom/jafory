import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = (relativePath: string) => readFileSync(resolve(process.cwd(), relativePath), "utf8");

describe("authenticated admin resilience", () => {
  it("passes one auth snapshot into the dashboard shell instead of reading the session twice", () => {
    const adminPage = source("client/src/pages/AdminPage.tsx");
    const dashboard = source("client/src/components/DashboardLayout.tsx");

    expect(adminPage).toContain("auth={{ loading, user, logout }}");
    expect(dashboard).toContain("export type DashboardAuth");
    expect(dashboard).not.toContain("const { loading, user } = useAuth();");
    expect(dashboard).not.toContain("const { user, logout } = useAuth();");
  });

  it("shows a retryable account error instead of allowing a silent blank state", () => {
    const adminPage = source("client/src/pages/AdminPage.tsx");

    expect(adminPage).toContain("Jafory account could not be loaded");
    expect(adminPage).toContain("The sign-in session could not be read on this device");
    expect(adminPage).toContain("onClick={() => void refresh()}");
  });

  it("keeps the legacy /ad entry point inside the protected admin flow", () => {
    const app = source("client/src/App.tsx");

    expect(app).toContain('<Route path={"/ad"} component={LegacyAdminRoute} />');
    expect(app).toContain('setLocation("/admin", { replace: true })');
  });

  it("preserves the admin intent through the Supabase magic-link callback", () => {
    const authEntry = source("client/src/const.ts");
    const accountPage = source("client/src/pages/AccountPage.tsx");
    const adminPage = source("client/src/pages/AdminPage.tsx");

    expect(authEntry).toContain('callback.searchParams.set("next", safeNextPath(nextPath))');
    expect(authEntry).toContain('emailRedirectTo: callback.toString()');
    expect(adminPage).toContain('startLogin(undefined, "/admin")');
    expect(accountPage).toContain('nextPath === "/admin"');
    expect(accountPage).toContain('window.location.replace("/admin")');
  });

  it("wraps the application so an embedded-browser render exception has a visible fallback", () => {
    const main = source("client/src/main.tsx");
    const boundary = source("client/src/components/ErrorBoundary.tsx");

    expect(main).toContain("import ErrorBoundary from \"./components/ErrorBoundary\";");
    expect(main).toContain("<ErrorBoundary>");
    expect(boundary).toContain("An unexpected error occurred.");
    expect(boundary).toContain("Reload Page");
  });
});
