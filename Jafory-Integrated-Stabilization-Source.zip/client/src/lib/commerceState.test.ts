import { describe, expect, it } from "vitest";
import { defaultLanguageForMarket, isClientMarket, toggleComparisonProduct } from "./commerceState";

describe("client commerce state", () => {
  it("uses the correct regional default language when a market is selected", () => {
    expect(defaultLanguageForMarket("uae")).toBe("ar");
    expect(defaultLanguageForMarket("bangladesh")).toBe("bn");
    expect(defaultLanguageForMarket("global")).toBe("en");
    expect(isClientMarket("uae")).toBe(true);
    expect(isClientMarket("other")).toBe(false);
  });

  it("adds, removes, and limits comparison selections in the client experience", () => {
    expect(toggleComparisonProduct([1, 2], 3)).toEqual([1, 2, 3]);
    expect(toggleComparisonProduct([1, 2, 3], 2)).toEqual([1, 3]);
    expect(toggleComparisonProduct([1, 2, 3, 4], 5)).toEqual([1, 2, 3, 4]);
  });
});
