import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function isPhoneUserAgent(userAgent: string) {
  return /android|iphone|ipod|mobile|iemobile|opera mini/i.test(userAgent);
}

function isMobileEnvironment() {
  const compactViewport = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`).matches;
  const phoneUserAgent = isPhoneUserAgent(navigator.userAgent);
  return compactViewport || phoneUserAgent;
}

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(
    undefined
  );

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(isMobileEnvironment());
    };
    mql.addEventListener("change", onChange);
    setIsMobile(isMobileEnvironment());
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return !!isMobile;
}
