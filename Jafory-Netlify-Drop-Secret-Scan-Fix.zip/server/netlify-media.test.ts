import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { canonicalStorageImages, safePublicMediaUrl, toNetlifyMediaPath } from "@shared/storageImageMap";

const publicDir = "/home/ubuntu/jafory-affiliate-hub/client/public";

describe("Netlify-owned Jafory media", () => {
  it("normalizes every canonical product image into a package-owned public URL", () => {
    const urls = Object.values(canonicalStorageImages).filter((value): value is string => Boolean(value)).map(toNetlifyMediaPath);
    expect(urls).toHaveLength(118);
    expect(urls.every(url => url?.startsWith("/jafory-media/"))).toBe(true);
    expect(urls.some(url => url?.includes("/manus-storage/"))).toBe(false);
  });

  it("includes every mapped product image and the Jafory logo in the public bundle", () => {
    const filenames = new Set(Object.values(canonicalStorageImages).filter((value): value is string => Boolean(value)).map(value => path.basename(toNetlifyMediaPath(value) ?? "")));
    expect(filenames.size).toBe(94);
    for (const filename of filenames) expect(existsSync(path.join(publicDir, "jafory-media", filename))).toBe(true);
    expect(existsSync(path.join(publicDir, "jafory-logo.webp"))).toBe(true);
  });

  it("uses the package-owned logo in both public navigation locations", () => {
    const layout = readFileSync(path.join(publicDir, "..", "src", "components", "StorefrontLayout.tsx"), "utf8");
    expect(layout).toContain('src="/jafory-logo.webp"');
    expect(layout).not.toContain("/manus-storage/jafory-logo");
  });

  it("does not pass editable preview-only media paths into public catalogue responses", () => {
    expect(safePublicMediaUrl("/manus-storage/admin-upload.webp")).toBeNull();
    expect(safePublicMediaUrl("https://jaforyhub.manus.space/manus-storage/admin-upload.webp")).toBeNull();
    expect(safePublicMediaUrl("https://cdn.example.com/product.webp")).toBe("https://cdn.example.com/product.webp");
  });

  it("builds a directly uploaded Netlify Drop source package rather than searching for a nested archive", () => {
    const netlifyToml = readFileSync("/home/ubuntu/jafory-affiliate-hub/netlify.toml", "utf8");
    expect(netlifyToml).toContain('command = "pnpm install --frozen-lockfile && pnpm build"');
    expect(netlifyToml).not.toContain("unzip -q");
    expect(netlifyToml).not.toContain("find . -maxdepth 1 -type f -iname '*.zip'");
  });

  it("does not repeat the live Supabase project URL in package documentation", () => {
    const guide = readFileSync("/home/ubuntu/jafory-affiliate-hub/NETLIFY_SUPABASE_BN.md", "utf8");
    expect(guide).not.toContain("ehbhngznkxngxarquihn.supabase.co");
    expect(guide).toContain("এটি secret নয়");
  });
});
