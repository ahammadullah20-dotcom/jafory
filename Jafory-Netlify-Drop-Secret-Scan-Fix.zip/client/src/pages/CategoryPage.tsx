import { ArrowLeft, Grid2X2, Layers3 } from "lucide-react";
import { useRoute } from "wouter";
import CatalogProductCard from "@/components/CatalogProductCard";
import StorefrontLayout from "@/components/StorefrontLayout";
import { useCommerce } from "@/contexts/CommerceContext";
import { localized, ui } from "@/lib/localization";
import { trpc } from "@/lib/trpc";

export default function CategoryPage() {
  const [, params] = useRoute("/categories/:slug");
  const slug = params?.slug ?? "";
  const shell = trpc.catalog.home.useQuery();
  const query = trpc.catalog.category.useQuery({ slug });
  const { language } = useCommerce();
  const copy = ui(language);
  const content = query.data;
  const countLabel = content && content.products.length === 1 ? copy.productLabel : copy.productsLabel;

  return <StorefrontLayout categories={shell.data?.categories ?? []} socialLinks={shell.data?.socialLinks ?? []} settings={shell.data?.settings ?? []}>
    <section className="catalog-hero"><div className="container"><a className="breadcrumb" href="/"><ArrowLeft size={14} />{copy.returnHome}</a>{content ? <><p className="eyebrow eyebrow--dark"><span className="eyebrow__dot" />{copy.categories}</p><h1>{localized(content.category, "name", language)}</h1><p>{localized(content.category, "description", language)}</p></> : <><h1>{copy.categories}</h1><p>{copy.chooseCategory}</p></>}</div></section>
    <section className="section catalog-section"><div className="container">{query.isLoading ? <div className="page-loading">{copy.searching}</div> : content ? <><div className="catalog-meta"><span><Grid2X2 size={16} />{content.products.length} {countLabel}</span><span>{copy.compareLimit}</span></div>{content.products.length ? <div className="product-grid">{content.products.map(product => <CatalogProductCard key={product.id} product={product} category={content.category} />)}</div> : <div className="empty-catalog"><Layers3 size={28} /><p>{copy.noProducts}</p></div>}</> : <div className="empty-catalog"><Layers3 size={28} /><p>{copy.noProducts}</p></div>}</div></section>
  </StorefrontLayout>;
}
